// QuantumState.ts — simplified Complex-backed quantum state
import { complex, Complex } from 'mathjs';

export class QuantumState {
  private stateVector: Complex[];

  constructor(vec?: Complex[]) {
    this.stateVector = vec ? [...vec] : [];
  }

  getStateVector(): Complex[] {
    return this.stateVector;
  }

  getAmplitude(i: number): Complex {
    return this.stateVector[i] ?? complex(0, 0);
  }

  setAmplitude(i: number, value: Complex): void {
    this.stateVector[i] = value ?? complex(0, 0);
  }

  size(): number {
    return this.stateVector.length;
  }
}
