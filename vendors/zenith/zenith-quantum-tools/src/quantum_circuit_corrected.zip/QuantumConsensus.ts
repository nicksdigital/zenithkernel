import { QuantumState } from './QuantumState';
import { applyControlledGate } from './QuantumOperations';
import { hadamard, phase } from './QuantumGates';
import { calculateFidelity } from './QuantumUtils';

export interface ConsensusConfig {
  num_parties: number;
  num_qubits_per_party: number;
  max_rounds: number;
  error_threshold: number;
  use_entanglement: boolean;
}

export interface ConsensusResult {
  success: boolean;
  rounds_taken: number;
  measurements: number[];
  final_states: QuantumState[];
  fidelity: number;
}

function createMultiPartyEntanglement(numParties: number, qubitsPerParty: number): QuantumState {
  const state = new QuantumState(numParties * qubitsPerParty);
  for (let i = 0; i < numParties; i++) state.applyHadamard(i * qubitsPerParty);
  for (let i = 0; i < numParties - 1; i++) {
    applyControlledGate(state, i * qubitsPerParty, (i + 1) * qubitsPerParty, phase(Math.PI / 2));
  }
  return state;
}

function createEntangledStates(numParties: number, qubitsPerParty: number): QuantumState[] {
  const states: QuantumState[] = [];
  const entangled = createMultiPartyEntanglement(numParties, qubitsPerParty);
  for (let i = 0; i < numParties; i++) {
    const state = new QuantumState(qubitsPerParty);
    for (let j = 0; j < qubitsPerParty; j++) {
      const idx = i * qubitsPerParty + j;
      state.setAmplitude(j, entangled.getAmplitude(idx));
    }
    states.push(state);
  }
  return states;
}

function performVotingRound(states: QuantumState[], round: number): number[] {
  return states.map(s => s.getMeasurementOutcomes()[0] ? 1 : 0);
}

function checkConsensus(measurements: number[], threshold: number): boolean {
  if (measurements.length === 0) return false;
  const counts = [0, 0];
  for (const m of measurements) counts[m]++;
  const ratio = Math.max(...counts) / measurements.length;
  return ratio >= threshold;
}

export function quantumByzantineAgreement(config: ConsensusConfig, initialStates: QuantumState[]): ConsensusResult {
  const result: ConsensusResult = { success: false, rounds_taken: 0, measurements: [], final_states: [], fidelity: 0 };

  if (initialStates.length !== config.num_parties) return result;

  const entangled = createMultiPartyEntanglement(config.num_parties, config.num_qubits_per_party);
  const states = initialStates.map(s => s.tensorProduct(entangled));

  while (result.rounds_taken < config.max_rounds) {
    const measurements = performVotingRound(states, result.rounds_taken);
    if (checkConsensus(measurements, config.error_threshold)) {
      result.success = true;
      result.measurements = measurements;
      break;
    }
    result.rounds_taken++;
  }

  result.final_states = states;
  result.fidelity = calculateFidelity(states[0], states[1]);
  return result;
}

export function quantumLeaderElection(config: ConsensusConfig): ConsensusResult {
  let states = Array.from({ length: config.num_parties }, () => {
    const s = new QuantumState(config.num_qubits_per_party);
    s.applyHadamard(0);
    return s;
  });

  if (config.use_entanglement) {
    states = createEntangledStates(config.num_parties, config.num_qubits_per_party);
  }

  const measurements = performVotingRound(states, 0);
  const result: ConsensusResult = {
    success: true,
    rounds_taken: 1,
    measurements,
    final_states: states,
    fidelity: 1.0
  };

  return result;
}

export function quantumDistributedKeyGeneration(config: ConsensusConfig): ConsensusResult {
  let states = Array.from({ length: config.num_parties }, () => {
    const s = new QuantumState(config.num_qubits_per_party);
    for (let j = 0; j < config.num_qubits_per_party; j++) {
      s.applyHadamard(j);
      s.applyPhase(j, Math.PI / 4);
    }
    return s;
  });

  if (config.use_entanglement) {
    states = createEntangledStates(config.num_parties, config.num_qubits_per_party);
  }

  const measurements = performVotingRound(states, 0);
  return {
    success: true,
    rounds_taken: 1,
    measurements,
    final_states: states,
    fidelity: 1.0
  };
}

export function verifyConsensus(result: ConsensusResult, config: ConsensusConfig): boolean {
  return result.success && result.rounds_taken <= config.max_rounds && checkConsensus(result.measurements, config.error_threshold);
}