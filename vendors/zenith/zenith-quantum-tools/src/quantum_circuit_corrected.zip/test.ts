import { QuantumState } from './QuantumState';
import { quantumByzantineAgreement, quantumLeaderElection, quantumDistributedKeyGeneration, verifyConsensus } from './QuantumConsensus';
import { entangleBytes } from './QuantumZkp';
import { verifyProof } from './verify';

const config = {
  num_parties: 3,
  num_qubits_per_party: 2,
  max_rounds: 5,
  error_threshold: 0.6,
  use_entanglement: true
};

async function runFullQuantumTest() {
  console.log("🧪 Testing Quantum Leader Election...");
  const election = quantumLeaderElection(config);
  console.log("✅ Leader Election Result:", election.measurements);

  console.log("🧪 Testing Quantum Distributed Key Generation...");
  const keygen = quantumDistributedKeyGeneration(config);
  console.log("✅ Shared Key Bits:", keygen.measurements);

  console.log("🧪 Testing Quantum Byzantine Agreement...");
  const initialStates = Array.from({ length: config.num_parties }, () => new QuantumState(config.num_qubits_per_party));
  const consensus = quantumByzantineAgreement(config, initialStates);
  console.log("✅ Consensus Measurements:", consensus.measurements);
  console.log("   ✔️ Reached?", consensus.success, "| Fidelity:", consensus.fidelity);

  console.log("🧪 Verifying Consensus...");
  const isValid = verifyConsensus(consensus, config);
  console.log("✅ Consensus Valid:", isValid);

  console.log("🧬 Creating Quantum ZKP Proof from raw bytes...");
  const message = new TextEncoder().encode("quantum zk test");
  const { proof, publicSignals } = await entangleBytes(message, 4);
  console.log("✅ Generated proof:", proof);

  console.log("🔍 Verifying ZKP proof...");
  const verified = await verifyProof(proof, publicSignals);
  console.log("🔐 ZKP Proof Valid?", verified);
}

runFullQuantumTest().catch(console.error);