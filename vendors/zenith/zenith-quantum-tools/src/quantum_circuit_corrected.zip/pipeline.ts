import { quantumLeaderElection, quantumDistributedKeyGeneration, quantumByzantineAgreement, verifyConsensus } from './QuantumConsensus';
import { entangleBytes } from './QuantumZkp';
import { verifyProof } from './verify';
import { QuantumState } from './QuantumState';

export async function runQuantumPipeline(input: Uint8Array, qubits = 4) {
  const config = {
    num_parties: 3,
    num_qubits_per_party: 2,
    max_rounds: 5,
    error_threshold: 0.6,
    use_entanglement: true
  };

  const leader = quantumLeaderElection(config);
  const keygen = quantumDistributedKeyGeneration(config);
  const consensus = quantumByzantineAgreement(config, Array.from({ length: config.num_parties }, () => new QuantumState(config.num_qubits_per_party)));
  const consensusValid = verifyConsensus(consensus, config);

  const zkp = await entangleBytes(input, qubits);
  const zkpValid = await verifyProof(zkp.proof, zkp.publicSignals);

  return {
    leader,
    keygen,
    consensus,
    consensusValid,
    zk: {
      proof: zkp.proof,
      signals: zkp.publicSignals,
      valid: zkpValid
    }
  };
}